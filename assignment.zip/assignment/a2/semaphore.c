#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<semaphore.h>


sem_t semaphore;
void *sem(void *num)
{
	sem_wait(&semaphore);
	printf("\nthread %d is executed \n",*(int*)num);
	sleep(1);
	sem_post(&semaphore);
	free(num);
	
}
int main()
{
	pthread_t t1,t2,t3,t4;
	sem_init(&semaphore, 0 ,1);
	int *n1 = malloc(sizeof(int));
	int *n2 = malloc(sizeof(int));
	int *n3 = malloc(sizeof(int));
	int *n4 = malloc(sizeof(int));
	*n1 = 1;
	*n2 = 2;
	*n3 = 3;
	*n4 = 4;
	pthread_create(&t1,NULL,sem,n1);
	pthread_create(&t2,NULL,sem,n2);
	pthread_create(&t3,NULL,sem,n3);
	pthread_create(&t4,NULL,sem,n4);

	pthread_join(t1, NULL);
	pthread_join(t2, NULL);
	pthread_join(t3, NULL);
	pthread_join(t4, NULL);

	return 0;
}











