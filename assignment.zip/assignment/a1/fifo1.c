#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>
#include<unistd.h>
#include<sys/types.h>
#include<errno.h>
#include<fcntl.h>
#include<sys/stat.h>
int main()
{
    int fd = open("myfile",O_WRONLY);
    int arr[] = {1,2,3,4,5};
    for(int i =0;i<5;i++)
    {
        write(fd,&arr[i],sizeof(arr[i])); 
    }
    close(fd);
}