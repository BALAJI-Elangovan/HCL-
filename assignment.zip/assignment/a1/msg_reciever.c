#include<stdio.h>
#include<sys/ipc.h>
#include<sys/msg.h>

struct buffer
{
    long msg_type;
    char msg_txt[100];
}msg;
int main()
{
    key_t key;
    int msgid;
    key = ftok("msgfile",65);
    msgid = msgget(key,0666 | IPC_CREAT);
    msgrcv(msgid,&msg,sizeof(msg),1,0);
    printf("\n Data recived : %s\n",msg.msg_txt);
    msgctl(msgid,IPC_RMID,NULL);
    return 0;
}