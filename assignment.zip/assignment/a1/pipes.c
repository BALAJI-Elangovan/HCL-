#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<pthread.h>

int main()
{
    int fd[2];
    //fd[0]=reading;
    //fd[1]=writing;
    pipe(fd);
    int id = fork();
    if(id==0)
    {
        wait(NULL);
        int x;
        close(fd[0]);
        printf("\n Enter the number to send from the child : ");
        scanf("%d",&x);
        write(fd[1],&x,sizeof(int));
        close(fd[1]);
        printf("\n");
    } 
    else{
        int y;
        close(fd[1]);
        read(fd[0],&y,sizeof(int));
        close(fd[0]);
        printf("\n the value recieved from the child is : %d ",y);
        printf("\n");
        
    }
}