#include<stdio.h>
#include<sys/ipc.h>
#include<sys/msg.h>
struct buffer
{
    long msg_type;
    char msg_txt[100];
}msg;
int main()
{
    key_t key;
    int msgid;
    key = ftok("msgfile",65);
    msgid = msgget(key, 0666|IPC_CREAT);
    msg.msg_type = 1;
    printf("\nwriting \n");
    fgets(msg.msg_txt,100,stdin);
    printf("\n message sending \n");
    msgsnd(msgid,&msg,sizeof(msg),0);
    printf("\n message is sended\n");
}
