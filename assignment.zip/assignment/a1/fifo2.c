#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<errno.h>
#include<fcntl.h>
int main()
{
    int fd = open("myfile",O_RDONLY);
    int arr[5];
    for(int i =0;i<5;i++)
    {
        read(fd,&arr[i],sizeof(arr[i]));
        printf("\nrecived : %d\n",arr[i]);
    }
    close(fd);
}